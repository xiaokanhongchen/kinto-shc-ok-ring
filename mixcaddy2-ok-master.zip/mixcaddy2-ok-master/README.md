# mixcaddy#######
https://github.com/ringring1/mixcaddy
[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://dashboard.heroku.com/new?template=https://github.com/ringring1/mixcaddy)  
#######

caddy v2 ok gost ok
test time 1001:2206

#######
https://github.com/ringring1/mixcaddy2-ok
[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://dashboard.heroku.com/new?template=https://github.com/ringring1/mixcaddy2-ok)
#######
